<?php
$xml=simplexml_load_file("https://www.eyefootball.com/rss_news_transfers.xml");
print_r($xml);
?>