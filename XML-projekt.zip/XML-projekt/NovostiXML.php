<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>XML-projekt</title>
        <meta name="description" content="XML-projekt na temu najboljih nogometaša svijeta">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="novosti.css" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Fraunces&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <header>
        <div class="container">
        <div class="row linkovi">
            <div class="col-lg-6 col-md-12 lijevi">
                <i class="fas fa-futbol fa-2x"></i>
                <h2 class="linija">Novosti</h2>
            </div>
            <div class="col-lg-6 col-md-12 desni">
                <nav>
                    <ul>
                        <li><a href="#">Ocijeni nas</a></li>
                        <li><a href="#">Soba s trofejima</a></li>
                        <li><a href="#">Novi igrači</a></li>
                        <li><a href="naslovnica.html">Povratak na naslovnicu</a></li>
                    </ul>
                </nav>
            </div>
        </div>
        </div>
        </header>
        <img src="images/Head.jpg" alt="" /> 
        <div class="container">
            <div class="row razmak">
                <?php
                $xml=simplexml_load_file("https://www.eyefootball.com/rss_news_transfers.xml");
                foreach($xml->channel->item as $itm){
                    $title=$itm->title;
                    $link=$itm->link;
                    $description=$itm->description;
                    $date=$itm->pubdate;
                    echo '<div class="col-6">';
                    echo "<h2>$title</h2>";
                    echo "<style> 
                        #bojaLinka {
                            text-align:center;
                            margin: 0 auto;
                            width:100px;
                        }
                        #bojaLinka:hover{
                            background-color: green;
                        }
                    </style>";
                    echo "<a href='$link' id='bojaLinka' style='color:black;text-align:center;'>Link za vijest</a>";
                    echo "<hr>";
                    echo "<p>$description</p>";
                    echo '</div>';
                }
                ?>
            </div> 
        </div>
    <footer>
        <div class="container">
            <div class="row center">
                <div class="col-2 razmak">
                    <i class="fas fa-running fa-3x"></i>
                </div>
                <div class="col-8"> 
                    <p>Renato Šplajt 0246095958</p>
                </div>
                <div class="col-2 razmak">
                    <i class="fas fa-award fa-3x"></i>
                </div>
            </div>
        </div>
    </footer>
    </body>
</html>
